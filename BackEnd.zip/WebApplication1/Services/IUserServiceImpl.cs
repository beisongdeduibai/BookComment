﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Writers;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using WebApplication1.Data;
using WebApplication1.Models;

namespace WebApplication1.Services
{
    public class IUserServiceImpl : IUserService
    {
        private readonly ApplicationDbContext context;
        private readonly IConfiguration _config;

        public IUserServiceImpl(ApplicationDbContext context, IConfiguration conf)
        {
            this.context = context;
            this._config = conf;
        }

        public bool AddUser(User user)
        {
            context.User.Add(user);
            var res = context.SaveChanges();
            return res > 0;
        }

        public bool DeleteUser(int id)
        {
            var user = this.GetUserById(id);
            context.User.Remove(user);

            var res = context.SaveChanges();
            return res > 0;
        }

        public User GetUserById(int id)
        {
            var user = context.User.FirstOrDefault(user => user.id == id);
            return user;
        }

        public string Login(UserLogin userLogin)
        {
            var user = Authenticate(userLogin);

            if (user != null)
            {
                var token = Generate(user);
                return token;
            }
            return "undefined";
        }
        public string Generate(User user)
        {
            var securityKey = new Microsoft.IdentityModel.Tokens.SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config["Jwt:Key"]));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            var claims = new[]
            {
                new Claim("username", user.username),
                new Claim(ClaimTypes.NameIdentifier, user.id.ToString(), "id"),
                new Claim(ClaimTypes.Role, user.isAdmin, "role"),
            };

            var token = new JwtSecurityToken(_config["Jwt:Issuer"],
                _config["Jwt:Audience"],
                claims,
                expires: DateTime.Now.AddMinutes(30),
                signingCredentials: credentials);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        public User Authenticate(UserLogin userLogin)
        {
            var currentUser = context.User.FirstOrDefault(
                o => o.username.ToLower() == userLogin.username.ToLower() && o.password == userLogin.password);
            if (currentUser != null)
            {
                return currentUser;
            }
            return null;
        }

        public bool CheckUser(User user)
        {
            var orginalUser = context.User.FromSql($"select * from gench.User where username = {user.username}").ToList();
            if (orginalUser.Count() != 0)
            {
                if (orginalUser[0].password == user.password)
                {
                    return true;
                }
            }
            return false;
        }

        public bool UpdateUser(int id, User user)
        {
            //1. 方法一
            /*            var userId = context.User.Find(id);
                        userId.password = user.password;*/

            //2. 方法二
            //context.Entry(user).State = EntityState.Modified;

            //3. 方法三
            context.User.Attach(user);
            context.Entry(user).Property("password").IsModified = true;

            var res = context.SaveChanges();
            return res > 0;
        }

    }
}
