﻿using WebApplication1.Models;

namespace WebApplication1.Services
{
    public interface IUserService
    {
        bool AddUser(User user);

        bool DeleteUser(int id);

        bool UpdateUser(int id, User user);

        User Authenticate(UserLogin userLogin);

        string Generate(User user);

        string Login(UserLogin userLogin);

        bool CheckUser(User user);

        User GetUserById(int id);
    }
}
