﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApplication1.Models;

namespace WebApplication1.Services
{
    public class ICommentServiceImpl: ICommentService
    {
        private readonly ApplicationDbContext context;

        public ICommentServiceImpl(ApplicationDbContext context)
        {
            this.context = context;
        }

        public bool AddComment(Comment comment)
        {
            comment.createTime = DateTime.Now;
            context.Comment.Add(comment);
            var res = context.SaveChanges();
            return res > 0;
        }

        public bool DeleteComment(int id)
        {
            var comment = context.Comment.FirstOrDefault(o => o.id == id);
            context.Comment.Remove(comment);
            context.Comment.RemoveRange(context.Comment.Where(o => o.parentId == id));
            var resRoot = context.SaveChanges();
            return resRoot > 0;
        }

        public List<CommentList> GetComments()
        {
            List<Comment> rootComments = context.Comment.FromSql($"select * from gench.Comment where parentId = 0 order by id desc").ToList();
            List<CommentList> comments = new List<CommentList>();
            rootComments.ForEach(rootComment =>
            {
                List<Comment> reply = context.Comment.FromSql($"select * from gench.Comment where parentId = {rootComment.id} order by id desc").ToList();
                rootComment.parentId = null;
                comments.Add(new CommentList(rootComment, reply));
            });
            return comments;
        }

        public List<CommentList> GetCommentsByBid(int bid)
        {
            List<Comment> rootComments = context.Comment.FromSql($"select *from gench.Comment where (parentId = 0 or parentId IS NULL) and bid = {bid} order by id desc;").ToList();
            List<CommentList> comments = new List<CommentList>();
            rootComments.ForEach(rootComment =>
            {
                List<Comment> reply = context.Comment.FromSql($"select * from gench.Comment where parentId = {rootComment.id} and bid = {bid} order by id desc").ToList();
                rootComment.parentId = null;
                comments.Add(new CommentList(rootComment, reply));
            });
            return comments;
        }

        public int GetMaxId()
        {
            var maxId = context.Comment.Select(o => o.id).Max();
            return maxId;
        }
    }
}
