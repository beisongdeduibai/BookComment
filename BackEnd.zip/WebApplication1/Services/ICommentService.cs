﻿using WebApplication1.Models;

namespace WebApplication1.Services
{
    public interface ICommentService
    {

        bool AddComment(Comment comment);
        bool DeleteComment(int id);
        List<CommentList> GetComments();
        List<CommentList> GetCommentsByBid(int bid);
        public int GetMaxId();
    }
}
