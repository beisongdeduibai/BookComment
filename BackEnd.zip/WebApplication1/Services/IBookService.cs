﻿using WebApplication1.Models;

namespace WebApplication1.Services
{
    public interface IBookService
    {
        bool AddBook(Book book);
        bool DeleteBook(int id);
        Book GetBook(int id);
        List<Book> GetBooks();
        bool UpdateBook(int id, Book book);
    }
}
