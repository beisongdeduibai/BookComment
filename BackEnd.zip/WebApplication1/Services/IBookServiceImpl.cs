﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApplication1.Models;

namespace WebApplication1.Services
{
    public class IBookServiceImpl: IBookService
    {
        private readonly ApplicationDbContext context;

        public IBookServiceImpl(ApplicationDbContext dbContext)
        {
            this.context = dbContext;
        }

        public bool AddBook(Book book)
        {
            context.Book.Add(book);
            var res = context.SaveChanges();
            return res > 0;
        }

        public bool DeleteBook(int id)
        {
            var book = GetBook(id);
            context.Book.Remove(book);
            var res = context.SaveChanges();
            return res > 0;
        }

        public Book GetBook(int id)
        {
            var book = context.Book.Single(book => book.Id == id);
            return book;
        }

        public List<Book> GetBooks()
        {
            List<Book> bookList = context.Book.ToList();
            return bookList;
        }

        public bool UpdateBook(int id, Book book)
        {
            context.Entry(book).State = EntityState.Modified;
            var res = context.SaveChanges();
            return res > 0;
        }
    }
}
