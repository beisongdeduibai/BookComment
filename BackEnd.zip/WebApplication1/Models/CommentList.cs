﻿namespace WebApplication1.Models
{
    public class CommentList
    {
        public Comment comments { get; set; }

        public List<Comment> reply { get; set; }

        public CommentList(Comment comments, List<Comment> reply)
        {
            this.comments = comments;
            this.reply = reply;
        }

    }
}
