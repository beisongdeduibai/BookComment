﻿namespace WebApplication1.Models
{
    public class Comment
    {
        public int id { get; set; }
        public int uid { get; set; }
        public int bid { get; set; }
        public Nullable<int> parentId { get; set; }
        public string? content { get; set; }
        public DateTime createTime { get; set; }
        public int like { get; set; }
        public string? username { get; set; }
    }
}
