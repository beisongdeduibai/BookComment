﻿namespace WebApplication1.Models
{
    public class Book
    {
        public int Id { get; set; }

        public string? book_name { get; set; }
        public string? author { get; set; }
        public string? content { get; set; }
        public string? book_face { get; set; }
        public string? face_suffix { get; set; }
        public int likes { get; set; }

    }
}
