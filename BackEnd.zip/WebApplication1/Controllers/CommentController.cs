﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using WebApplication1.Models;
using WebApplication1.Services;

namespace WebApplication1.Controllers
{
    [Route("[controller]/[action]")]
    [ApiController]
    public class CommentController : ControllerBase
    {
        private readonly ApplicationDbContext context;
        private readonly ICommentService commentService;

        public CommentController(ApplicationDbContext context, ICommentService commentService)
        {
            this.context = context;
            this.commentService = commentService;
        }

        [HttpPost]
        public bool AddComment([FromBody] Comment comment)
        {
            return commentService.AddComment(comment);
        }

        [HttpDelete("{id}")]
        public bool DeleteComment(int id)
        {
            return commentService.DeleteComment(id);
        }

        [HttpGet]
        public List<CommentList> GetComments()
        {
            return commentService.GetComments();
        }

        [HttpGet("{bid}")]
        public List<CommentList> GetCommentsByBid(int bid)
        {
            return commentService.GetCommentsByBid(bid);
        }

        [HttpGet]
        public int GetMaxId()
        {
            return commentService.GetMaxId();
        }


    }
}
