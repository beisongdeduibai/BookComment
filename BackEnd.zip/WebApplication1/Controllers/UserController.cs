﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using WebApplication1.Data;
using WebApplication1.Models;
using WebApplication1.Services;

namespace WebApplication1.Controllers
{

    [ApiController]
    [Route("[controller]/[action]")]
    public class UserController
    {
        private readonly ApplicationDbContext context;
        private readonly IConfiguration _config;
        private readonly IUserService userService;

        public UserController(ApplicationDbContext context, IConfiguration config, IUserService userService)
        {
            this.context = context;
            this._config = config;
            this.userService = userService;
        }

        [HttpPost]
        public bool AddUser([FromBody] User user)
        {
            return userService.AddUser(user);
        }

        [HttpPut("{id}")]
        public bool DeleteUser(int id)
        {
            return userService.DeleteUser(id);
        }

        [HttpGet("{id}")]
        [Authorize]
        public User GetUserById(int id)
        {
            return userService.GetUserById(id);
        }


        [AllowAnonymous]
        [HttpPost]
        public string Login([FromBody] UserLogin userLogin)
        {
            return userService.Login(userLogin);
        }

        [HttpPost]
        public bool CheckUser([FromBody] User user)
        {
            return userService.CheckUser(user);
        }

        [HttpPut("{id}")]
        public bool UpdateUser(int id, [FromBody] User user)
        {
            
            return userService.UpdateUser(id, user);
        }

    }
}
