﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using WebApplication1.Data;
using WebApplication1.Models;
using WebApplication1.Services;
using Microsoft.AspNetCore.Authorization;
using System.Data;

namespace WebApplication1.Controllers
{
    [ApiController]
    [Route("[controller]/[action]")]
    [Authorize]
    public class BookController
    {
        private readonly ApplicationDbContext context;
        private readonly IBookService bookService;

        public BookController(ApplicationDbContext dbContext, IBookService bookService)
        {
            this.context = dbContext;
            this.bookService= bookService;
        }

        [HttpPost]
        public bool AddBook(Book book)
        {
            return bookService.AddBook(book);
        }

        [HttpDelete("{id}")]
        public bool DeleteBook(int id)
        {
            return bookService.DeleteBook(id);
        }

        [HttpGet("{id}")]
        public Book GetBook(int id)
        {
            return bookService.GetBook(id);
        }

        [HttpGet]
        public List<Book> GetBooks()
        {
            return bookService.GetBooks();
        }

        [HttpPut("{id}")]
        public bool UpdateBook(int id, Book book)
        {
            return UpdateBook(id, book);
        }

    }
}
