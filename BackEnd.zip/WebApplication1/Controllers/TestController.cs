﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    [ApiController]
    [Route("api/[controller]/[action]")]
    public class TestController : ControllerBase
    {

        private readonly ApplicationDbContext _dbContext;
        public TestController(ApplicationDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        /// <summary>
        /// 创建
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public IActionResult Create()
        {
            var message = "";
            using (_dbContext)
            {
                var person = new User
                {
                    userName = "test",
                    password = "123",
                    phone_number= "123",
                    id_card= "123",

                };
                _dbContext.User.Add(person);
                var i = _dbContext.SaveChanges();
                message = i > 0 ? "数据写入成功" : "数据写入失败";
            }
            return Ok(message);
        }

        /// <summary>
        /// 读取指定Id的数据
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public IActionResult GetById(int id)
        {
            using (_dbContext)
            {
                var list = _dbContext.User.Find(id);
                return Ok(list);
            }
        }

        /// <summary>
        /// 读取所有
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public IActionResult GetAll()
        {
            using (_dbContext)
            {
                var list = _dbContext.User.ToList();
                return Ok(list);
            }
        }
    }
    
}
