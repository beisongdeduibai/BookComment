<template>
  <div>
    <div class="content">
      <div class="left">
<!--         <n-avatar
          round
          :size="80"
          src="api/avatar/x.jpg"
          v-show="store.getters.isLogin"
        /> -->
        <n-gradient-text type="info" :size="20">
          欢迎你， {{ store.getters.username }}
        </n-gradient-text>
      </div>

      <div>
        <n-button v-show="!store.getters.isLogin" quaternary type="primary" @click="login">
          登录
        </n-button>
        <n-button v-show="store.getters.isLogin" quaternary type="error" @click="logout">
          退出登录
        </n-button>
        <n-button quaternary type="info" @click="register">
          注册
        </n-button>
        <n-button strong secondary type="primary" @click="$router.push('home')">
          首页
        </n-button>
      </div>

    </div>
  </div>
</template>

<script setup>
  import router from '@/router'
  import { useStore } from 'vuex'

  const store = useStore()
  
  const login = () => {
    router.push('login')
  }

  const logout = () => {
    store.commit('logout')
    router.go(0)
  }

  const register = () => router.push('register')

</script>

<style scoped>
  .content {
    display: flex;
    justify-content: space-between;
    background-color: #95d5b2;
    width: 100%;
    height: 100px;
    margin-bottom: 1rem;
  }

</style>