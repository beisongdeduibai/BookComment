<template>

  <div class="content">
    <n-form ref="formRef" :inline="false" :label-width="80" :model="formValue" :rules="rules" :size="size">
      <n-form-item label="用户名" path="username">
        <n-input v-model:value="formValue.username" placeholder="请输入用户名" />
      </n-form-item>
      <n-form-item label="密码" path="password">
        <n-input v-model:value="formValue.password" placeholder="请输入密码" />
      </n-form-item>
      <n-form-item label="确认密码" path="repassword">
        <n-input v-model:value="formValue.repassword" placeholder="请再次输入密码" />
      </n-form-item>
      <n-form-item label="电话号码" path="phone_number">
        <n-input v-model:value="formValue.phone_number" placeholder="电话号码" />
      </n-form-item>
      <n-form-item label="身份证号码" path="id_card">
        <n-input v-model:value="formValue.id_card" placeholder="请输入身份证号码" />
      </n-form-item>
      <n-form-item>
        <n-button :loading="loading" :block="true" attr-type="button" @click="handleValidateClick">
          注册
        </n-button>
      </n-form-item>
    </n-form>
  </div>


  <!-- <pre> {{ JSON.stringify(formValue, null, 2) }} </pre> -->
</template>

<script setup>
  import { useMessage } from "naive-ui"
  import api from '@/api/api'
  import { useRouter } from 'vue-router'

  const formRef = ref(null)
  const message = useMessage()
  const size = ref("medium")
  const loading = ref(false)

  const router = useRouter()

  let formValue = ref({
    username: "",
    password: "",
    repassword: "",
    phone_number: "",
    id_card: "",
    isAdmin: '0'
  })

  let rules =  {
    username: {
      required: true,
      message: "请输入用户名",
      trigger: ["blur", "input"],
    },
    password: [{
      required: true,
      message: "请输入密码",
      trigger: ["blur", "input"],
    }],
    repassword: [{
      required: true,
      message: "请再次输入密码",
      trigger: ["blur", "input"]
    },
    {
      trigger: ["blur", "input"],
      validator(rule, value) {
        if (formValue.value.password !== value) {
          return new Error("两次密码输入不一致")
        }
      },
    },],
    phone_number: [{
      required: true,
      message: "请输入电话号码",
      trigger: ["blur", "input"]
    },
    {
      pattern: /^(13[0-9]|14[01456879]|15[0-35-9]|16[2567]|17[0-8]|18[0-9]|19[0-35-9])\d{8}$/,
      // pattern: /^\d{3}-\d{8}$/,
      message: "请输入正确格式的电话号码",
      trigger: ["blur", "input"]
    }],
    id_card: [{
      required: true,
      message: "请输入身份证号码",
      trigger: ["blur", "input"]
    },
    {
      pattern: /^([1-6][1-9]|50)\d{4}(18|19|20)\d{2}((0[1-9])|10|11|12)(([0-2][1-9])|10|20|30|31)\d{3}[0-9Xx]$/,
      message: "请输入正确的身份证号码",
      trigger: ["blur", "input"]
    }]
  }

  let handleValidateClick = e => {
    e.preventDefault();
    formRef.value?.validate((errors) => {
      if (!errors) {
        addUser(formValue.value)
        // console.log(formValue.value);
        console.log("valid");
      } else {
        console.log(errors);
        message.error("表单验证不通过");
      }
    });
  }

  let addUser = formData => {
    loading.value = true;
    api.userAPI.addUser(formData).then(res => {
      if (res === true) {
        // console.log(res);
        // console.log(formData);
        message.success("注册成功, 请登录");
        router.push('/Login')
      }
    }).catch(error => {
      console.log(error);
      loading.value = false
      message.error("服务器错误")
    })
  }

</script>

<style scoped>
 .content {
  max-width: 30rem;
  margin: 0 auto;
 }
</style>