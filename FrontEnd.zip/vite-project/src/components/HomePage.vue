<template>
  <div class="content">
    <div class="item" v-for="item in books">
      <n-image width="250" height="350" preview-disabled 
      @click="toBook(item)"
      :src="'api/BookPic/' + item.book_face + '.' + item.face_suffix"/>
      <div class="tips">
        <router-link :to="{path: 'Book', query: {id: item.id}}">
          {{ item.book_name }}
        </router-link>
      </div>
      <div class="tips">
        <n-tag type="info">{{item.author}}</n-tag>
      </div>
      <div class="tips">
        <n-ellipsis line-clamp="1" :tooltip="false">
          {{ item.content }}
        </n-ellipsis>
      </div>
    </div>
  </div>
</template>

<script setup>
  import api from '@/api/api'
  import { onMounted } from 'vue'
  import { useLoadingBar } from 'naive-ui'
  import { useRouter } from 'vue-router'

  let books = ref([])
  const loadingBar = useLoadingBar()
  const router = useRouter()

  onMounted(() => {
    GetBook()
  })

  const GetBook = () => {
    loadingBar.start()
    api.bookAPI.getBooks().then((res) => {
      books.value = res
      loadingBar.finish()
      // console.log(books);
    }).catch(error => {
      console.log(error)
      loadingBar.error()
    })
  }

  const toBook = book => {
    router.push({
      name: 'Book',
      query: {
        id: book.id
      }
    })
  }

</script>

<style lang="css" scoped>
  .n-image {
    justify-content: center;
  }
  .content {
    /* background-color: green; */
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
  }
  .item {
    /* background-color: skyblue; */
    display: flex;
    flex-direction: column;
    flex-basis: 33%;
    justify-content: center;
    margin-bottom: 50px;
  }
  .tips {
    display: block;
    text-align: center;
    cursor: pointer;
  }
</style>