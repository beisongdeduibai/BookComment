<template>
  <div>
      <n-image width="200" 
        :src="'api/BookPic/' + book.book_face + '.' + book.face_suffix"
        :previewed-img-props="{ style: { border: '8px solid white' } }" />
      <n-descriptions label-placement="left" title="描述">
        <n-descriptions-item label="书名" :span="2">
          {{ book.book_name }}
        </n-descriptions-item>
        <n-descriptions-item label="作者">
          {{ book.author }}
        </n-descriptions-item>
        <n-descriptions-item label="内容" :span="3">
          <n-ellipsis expand-trigger="click" line-clamp="2" :tooltip="false">
            {{ book.content }}
          </n-ellipsis>
        </n-descriptions-item>
      </n-descriptions>
      <div class="comment-view">
        <u-comment style="padding: 0px" :config="config" :show-size="2" @submit="submit" @like="like" @remove="remove" @report="report">
        </u-comment>
      </div>
  </div>
  <!-- <pre> {{ JSON.stringify(config.comments) }} </pre> -->
</template>

<script setup>
  import { onMounted, reactive } from 'vue'
  import emoji from '@/assets/emoji'
  import { useMessage } from 'naive-ui'
  import { useLoadingBar } from 'naive-ui'
  import api from '@/api/api'
  import { useRoute } from 'vue-router'
  import { useStore } from 'vuex'
  import timeago from '@/utils/time'

  const message = useMessage()
  const loadingBar = useLoadingBar()
  const route = useRoute()
  const store = useStore()

  const book = ref({})
  const config = reactive({
    user: {
      id: store.getters.userInfo.info.id,
      username: store.getters.userInfo.info.username,
      avatar: null,
      likeIds: [],
    },
    bid: ~~route.query.id,
    emoji: emoji,
    comments: []
  })
  
  onMounted(() => {
    loadingBar.start()
    const bid = route.query.id
    getBook(bid).then(res => {
      getCommentsByBid(bid)
    }).then(res => {
      loadingBar.finish()
      // console.log(book.value);
    }).catch(error => {
      loadingBar.error()
      console.log(error);
    })
  })

  const getBook = id => {
    return api.bookAPI.getBook(id).then(res => {
      book.value = res
      // console.log(res);
    }).catch(error => {
      console.log(error);
      throw new Error('getBook Error')
    })
  }

  const getCommentsByBid = id => {
    return api.commentAPI.getCommentsByBid(id).then(res => {
      // console.log(res);
      res.forEach(element => {
        element.comments.createTime = timeago(element.comments.createTime)
        let item = element.comments
        item.reply = []
        element.reply.forEach(item => {
          item.createTime = timeago(item.createTime)
        })
        item.reply.list = element.reply
        config.comments.push(item)
      })
    }).catch(error => {
      console.log(error);
      throw new Error('getCommentsByBid Error')
    })
  }

  let maxId
  const submit = async (content , parentId, finish) => {
    await api.commentAPI.getMaxId().then(res => {
      maxId = res
    })
    console.log(maxId, 'maxId');
    let comment = {
      id: maxId + 1,
      parentId: parentId || null,
      uid: config.user.id,
      username: config.user.username,
      bid: config.bid,
      like: 0,
      content: content,
      createTime: '刚刚'
      // address: '',
      // link: `/${(tempId += 1)}`,
    }
    finish(comment)
    let toComment = window.structuredClone(comment)
    submitToServer(toComment)
    // console.log(config.comments);
  }

  const submitToServer = (comment) => {
    console.log(comment);
    comment.createTime = undefined
    api.commentAPI.addComment(comment).then((res) => {
        console.log(res);
      if (res === true) {
        message.success('评论成功')
      }
    }).catch(error => {
      console.log(error);
      message.error('服务器错误')
    })
  }

  const like = (id, finish) => {
    finish()
    console.log(id)
  }

  const remove = (id, finish) => {
    console.log(id)
    finish()
    removeToServer(id)
  }

  const removeToServer = (id) => {
    api.commentAPI.deleteComment(id).then(res => {
      if (res === true) {
        message.success('删除成功')
      }
    }).catch(error => {
      console.log(error);
      message.error('服务器错误')
    })
  }
  const report = () => {
    message.warning('暂未开放~')
  }

  // config.comments = [
  //   {
  //     id: '1',
  //     parentId: null,
  //     uid: '1',
  //     username: 'username',
  //     content: '这本书好好看',
  //     like: 0
  //   },
  //   {
  //     id: '2',
  //     parentId: '2',
  //     uid: '2',
  //     username: '用户2',
  //     content: '大家好啊~',
  //     like: 1,
  //     reply: {
  //       total: 1,
  //       list: [
  //         {
  //           id: '5',
  //           parentId: '2',
  //           uid: '3',
  //           username: '用户3',
  //           content: '你好啊##[微笑]',
  //           like: 11
  //         }
  //     ]
  //     }
  //   }
  // ]

</script>

<style scoped>

</style>