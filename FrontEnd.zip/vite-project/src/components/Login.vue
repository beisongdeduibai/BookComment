<template>
  <div class="content">
    <n-form ref="formRef" :inline="false" :label-width="80" :model="formData" :rules="rules" :size="size">
      <n-form-item label="用户名" path="username">
        <n-input v-model:value="formData.username" placeholder="请输入用户名" />
      </n-form-item>
      <n-form-item label="密码" path="password">
        <n-input v-model:value="formData.password" placeholder="请输入密码" />
      </n-form-item>
      <n-form-item>
        <n-button 
        :block="true" 
        attr-type="button" 
        @click="handleValidateClick"
        :loading="loading">
           登录
        </n-button>
      </n-form-item>
    </n-form>
  </div>
  <!-- <pre> {{ JSON.stringify(formData, null, 2) }} </pre> -->
</template>

<script setup>
  import { useMessage } from "naive-ui"
  import api from '@/api/api'
  import { useRouter, useRoute } from 'vue-router'
  import { useStore } from 'vuex'
  import jwtDecode from 'jwt-decode'

  const formRef = ref(null)
  const message = useMessage()
  const size = ref('medium')
  const loading = ref(false)
  const store = useStore()

  const router = useRouter()

  let formData = ref({
    username: "",
    password: ""
  })

  let rules = {
    username: {
      required: true,
      message: "请输入用户名",
      trigger: ["blur", "input"]
    }, 
    password: {
      required: true,
      message: "请输入密码",
      trigger: ["input", "blur"]
    }
  }

  let handleValidateClick = e => {
    e.preventDefault()
    formRef.value?.validate(errors => {
      if (!errors) {
        checkUser(formData.value)
      } else {
        console.log(errors)
      }
    })
  }

  let checkUser = formData => {
    loading.value = true
    api.userAPI.login(formData).then(res => {
      if (res !== 'undefined') {
        console.log(jwtDecode(res));
        window.localStorage.setItem('token', res)
        const info = jwtDecode(res)
        message.success("登录成功")
        router.push('/Home')
        const userInfo = {
          info: {
            username: localStorage.getItem('token') && info.username,
            id: localStorage.getItem('token') && info['http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier'],
            role: localStorage.getItem('token') && info['http://schemas.microsoft.com/ws/2008/06/identity/claims/role'],
          },
          token: window.localStorage.getItem('token'),
          isLogin: window.localStorage.getItem('token') && true
        }
        store.commit('login', userInfo)
        // console.log(info, 'info');
      } else {
        loading.value = false
        message.error("用户名或密码错误")
      }
    }).catch(error => {
      console.log(error);
      loading.value = false
      message.error("服务器错误")
    })
  }

</script>

<style scoped>
 .content {
  max-width: 30rem;
  margin: 0 auto;
 }

</style>