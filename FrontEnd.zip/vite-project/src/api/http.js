import axios from 'axios'
import router from '@/router'
import store from '@/store'
import { createDiscreteApi } from 'naive-ui'

const { message, notification, dialog, loadingBar } = createDiscreteApi(
  ["message", "dialog", "notification", "loadingBar"],
);

axios.defaults.timeout = 10000;

// axios.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded;charset=UTF-8';

axios.interceptors.request.use(config => {
  const token = localStorage.getItem('token');
  token && (config.headers.authorization = `Bearer ${token}`);
  // console.log(config)
  return config;
}, error => {
  return Promise.reject(error);
});

axios.interceptors.response.use(response => {
  if (response.status === 200) {
    return Promise.resolve(response.data)
  } else {
    return Promise.reject(response)
  }
}, error => {
  if (error.response.status) {
    if (!window.localStorage.getItem('token')) {
      message.warning('请先登录');
      router.push('/login')
      return Promise.reject(error.response);
    }
    switch (error.response.status) {
      case 401:
        // localStorage.removeItem('token');
        store.commit('logout');
        message.error('登录过期，请重新登录');
        setTimeout(() => {
          router.push('/login')
        }, 1000)
        break;
      case 403:
        message.error('权限不足');
        localStorage.removeItem('token');
        break;
      case 404: router.replace({
        path: '/404',
      });
        break;
    }
    return Promise.reject(error.response);
  }
});

export default axios;