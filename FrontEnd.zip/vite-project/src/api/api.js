import book from '@/api/entity/book.js'
import comment from '@/api/entity/comment.js'
import user from '@/api/entity/user.js'

export default {
  bookAPI: book,
  commentAPI: comment,
  userAPI: user
}