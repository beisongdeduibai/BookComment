import axios from '@/api/http'

const getBooks = () => axios.get('api/Book/GetBooks')

const getBook = (id) => axios.get(`api/Book/GetBook/${id}`)

const addBook = (data) => axios.post('api/Book/AddBook', data)

const updateBook = (data) => axios.put('api/Book/UpdateBook', data)

export default {
  getBooks,
  getBook,
  addBook,
  updateBook
}