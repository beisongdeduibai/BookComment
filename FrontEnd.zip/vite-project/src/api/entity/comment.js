import axios from '@/api/http'

const getComments = () => axios.get('api/Comment/GetComments')

const getCommentsByBid = (id) => axios.get(`api/Comment/GetCommentsByBid/${id}`)

const addComment = (comment) => axios.post('api/Comment/AddComment', comment)

const deleteComment = (id) => axios.delete(`api/Comment/DeleteComment/${id}`)

const getMaxId = () => axios.get('api/Comment/GetMaxId')

export default {
  getComments,
  getCommentsByBid,
  addComment,
  deleteComment,
  getMaxId
}