import axios from '@/api/http.js'

const login = (data) => axios.post("/api/User/Login", data)

const addUser = (data) => axios.post("/api/User/AddUser", data)

export default {
  login,
  addUser
}