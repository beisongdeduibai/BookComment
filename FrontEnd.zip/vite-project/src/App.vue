<script setup>
  import MyHeader from '@/components/MyHeader.vue'
</script>

<template>
  <div class="app">
    <n-message-provider>
      <my-header/>
    </n-message-provider>
    
    <div class="main">
      <!-- <router-link to="/Home">Home</router-link>
      <router-link to="/Login">Login</router-link>
      <router-link to="/Register">Register</router-link>
      <router-link to="/Book">Book</router-link>
      <router-link to="/404">404</router-link> -->
      <n-message-provider>
        <n-loading-bar-provider>
          <router-view></router-view>
        </n-loading-bar-provider>
      </n-message-provider>
    </div>
  </div>
</template>

<style scoped>
  .main {
    max-width: 70%;
    margin: 0 auto;
  }
  @media only screen and (max-width: 600px) {
  .main {
    max-width: 90%;
  }
}
</style>
