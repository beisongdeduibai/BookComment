import HomePage from '@/components/HomePage.vue'
import Login from "@/components/Login.vue"
import Register from "@/components/Register.vue"
import Book from '@/components/Book.vue'
import * as VueRouter from 'vue-router'


const routes = [
  {
    path: '/',
    redirect: '/Home'
  },
  {
    path: '/Home',
    component: HomePage
  },
  {
    path: '/Login',
    component: Login
  },
  {
    path: '/Register',
    component: Register
  },
  {
    path: '/Book',
    name: "Book",
    component: Book,
    props: route => ({ query: route.query.id })
  },
  {
    path: '/:pathMatch(.*)*',
    component: () => import('@/components/404.vue')
  },

]

const router = VueRouter.createRouter( {
  history: VueRouter.createWebHistory(),
  routes: routes,
})

/* router.beforeEach((to, from, next) => {
  if (to.meta.requireAuth) {
    if ( window.localStorage.getItem('token') ) {
      next()
    } else {
      next({
        path: '/Login',
        query: { redirect: to.fullPath }
      })
    }
  } else {
    next()
  }
}) */

export default router