import { createStore } from 'vuex'
import jwtDecode from 'jwt-decode'

const store = createStore({
  state: {
    userInfo: {
      info: {
        username: localStorage.getItem('token') && jwtDecode(localStorage.getItem('token')).username,
        id: localStorage.getItem('token') && jwtDecode(localStorage.getItem('token'))['http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier'],
        role: localStorage.getItem('token') && jwtDecode(localStorage.getItem('token'))['http://schemas.microsoft.com/ws/2008/06/identity/claims/role'],
      },
      token: window.localStorage.getItem('token'),
      isLogin: window.localStorage.getItem('token') && true
    }
  },

  getters:{
    isLogin: state => state.userInfo.isLogin,
    userInfo: state => state.userInfo,
    username: state => state.userInfo.info.username,
  },

  mutations: {
    login(state, payload) {
      state.userInfo = payload
    },
    logout(state) {
      state.userInfo = {}
      localStorage.clear()
    }
  },
})

export default store