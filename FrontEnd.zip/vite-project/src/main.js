import { createApp } from 'vue'
// import './style.css'
import App from '@/App.vue'
import router from '@/router'
import store from '@/store'

import UndrawUi from 'undraw-ui'
import 'undraw-ui/dist/style.css'


import {
  // create naive ui
  create,
  // component
  NButton
} from 'naive-ui'

const naive = create({
  components: [NButton]
})

const app = createApp(App)
app.use(naive)
app.use(UndrawUi)
app.use(router)
app.use(store)
app.mount('#app')
